#include "F28x_Project.h"

#define TRUE  1
#define FALSE 0
#define PI              3.1415927
#define TWO_PI          6.2831853
#define SQRT3           1.7320508
#define SQRT3_OVER_2    0.8660254
#define PI_OVER_3       1.0471976
#define PI_OVER_6       0.5235988
#define PI_OVER_2       1.5707963
#define TWO_PI_OVER_3   2.0943951
#define FIVE_PI_OVER_6  2.6179939
#define SEVEN_PI_OVER_6 3.6651914
#define FOUR_PI_OVER_3  4.1887902
#define THREE_PI_OVER_2 4.7123890
#define FIVE_PI_OVER_3  5.2359878
#define ELEVEN_PI_OVER_6  5.7595865
#define TWO_SQRT3       3.4641016
#define ONE_OVER_SQRT3  0.5773503
#define TWO_OVER_SQRT3  1.1547005
#define DEGREES_PER_RAD 57.2957795
#define RADS_PER_DEGREE 0.0174533
#define EXP             2.7182818

// Clock definitions
#define CPU_FREQ_MHz 120 // CPU frequency in MHz
#define CPU_FREQ_GHz 0.120 // CPU frequency in GHz
#define LSPCLK_FREQ_Hz 30000000 // Low speed clock frequency
#define MAX_SW_FREQ_kHz 40 // Max switching frequency in kHz
#define TIMER0_PERIOD  0.0001

#define MODBUS_ADDRESS  120 // Our MODBUS slave address

#define MOD_IR_TOP_STATE        0
#define MOD_IR_FAULT_CODE       1
#define MOD_IR_TEMP		2
#define MOD_IR_CURRENTx10       3
#define MOD_IR_MINS_TESTED      4

// MODBUS holding registers
#define MOD_HR_GUI_FLAG         0
#define MOD_HR_ON_FLAG          1
#define MOD_HR_RESET            2
#define MOD_HR_ILIM             3
#define MOD_HR_STAY_ON          4
#define MOD_HR_DUR              5 // Test duration in minutes
#define MOD_HR_CAL_T_VAL        6
#define MOD_HR_CAL_T_DUE        7

#define MOD_IR_COUNT    5 // Number of input registers
#define MOD_HR_COUNT    8 // Number of holding registers

// State definitions
#define SM_INIT      0
#define SM_OFF       1
#define SM_ON        2
#define SM_IDLE      3
#define SM_TIMEOUT   4
#define SM_FAULT     5

// I/O masks
#define ALL_OFF_MASK 0x01000000 // Everything off except GUI LED

// Measurement factors, limits
#define MAX_T      473 // In K
// Current sensor output: 5 mV/A, 2.5 V @ 0 A, 0.5 to 4.5 V corresponds to -400 to +400 A
// Current sensor output is resistor-divided 0.733: 3.665 mV/A, 1.83 V @ 0 A, 0.3665 to 3.298 V corresponds to -400 to +400 A
#define AMPS_PER_COUNTx10 2.19887 // 272.86 A/V * 3.3 V/4095 counts * 10 GUI scale factor = 2.198869739853
#define ZERO_AMPS 2270 // Zero current in counts = (4095 / 3.3 V) * 1.83 V = 2270
#define DEG_PER_COUNT -0.25183 // 3.3V/4095 * K/-0.0032V = -0.25183
#define ADCRES_CURRENT AdcaResultRegs.ADCRESULT0
#define ADCRES_TJ      AdcaResultRegs.ADCRESULT1

#define ADC_NUM_CH  2
#define CURRENT     0
#define TEMPERATURE 1

// First order filter channels
#define FLTR2_NUM_CH 2
#define CURRENT_FLTR 0
#define TJ_FLTR      1

#define DISABLED 0
#define ENABLED  1

// Comm channels
#define SCI_A  0 // MODBUS comm with host
#define SCI_B  1
#define SCI_C  2
#define SCI_D  3
#define SCI_FIFO_FULL_CNT 15 // SCI FIFO depth minus 1

#define GUI_LED_ON      GpioDataRegs.GPACLEAR.bit.GPIO24 = 1 // LED1 on
#define GUI_LED_OFF     GpioDataRegs.GPASET.bit.GPIO24 = 1 // LED1 off
#define GUI_LED_TOGGLE  GpioDataRegs.GPATOGGLE.bit.GPIO24 = 1
#define MODE_LED_ON     GpioDataRegs.GPBCLEAR.bit.GPIO39 = 1 // LED2 on
#define MODE_LED_OFF    GpioDataRegs.GPBSET.bit.GPIO39 = 1 // LED2 off
#define MODE_LED_TOGGLE GpioDataRegs.GPBTOGGLE.bit.GPIO39 = 1 // LED2 toggle
#define BREAKER_ON      GpioDataRegs.GPASET.bit.GPIO0 = 1
#define BREAKER_OFF     GpioDataRegs.GPACLEAR.bit.GPIO0 = 1


typedef struct
{
  unsigned millisecond, halfSecond, runCntr;
}timeStruct;

typedef struct
{
  unsigned zeroCurrentAdcCnt, TjMeas, TjEntered;
  char currentCalDue;
}calStruct;

typedef struct // First order filter structure
{
  float x[2], y[2]; // x[0] takes dirty input, y[0] stores the "clean" output value
}filter1struct;

typedef struct  // Second order filter structure
{
  float x[3], y[3]; // x[0] takes dirty input, y[0] stores the "clean" output value
}filter2struct;
