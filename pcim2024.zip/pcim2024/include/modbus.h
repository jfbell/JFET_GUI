#ifndef DSP28x_PROJECT_H
#include "F28x_Project.h"
#endif

#ifndef MODBUS_H_
#define MODBUS_H_

#define MOD_BAUD_RATE  19200 // MODBUS default baud rate
#define MOD_BUF_LENGTH  32 // Length of transmit/receive buffers

// MODBUS states
#define MOD_INIT       0
#define MOD_IDLE       1
#define MOD_RECEIVE    2
#define MOD_CTRL_WAIT  3

// MODBUS timer stuff
#define T1_1P5_TIME  938 // 1.5 bytes * 12 bits per byte / 19200 baud * 1E6 = 938 microseconds
#define T1_2P0_TIME 1250 // 2.0 bytes * 12 bits per byte / 19200 baud * 1E6 = 2188 microseconds
#define T1_3P5_TIME 2188 // 3.5 bytes * 12 bits per byte / 19200 baud * 1E6 = 2188 microseconds

// MODBUS function codes
#define FC_READ_HOLD_REGISTERS       3
#define FC_READ_INPUT_REGISTERS      4
#define FC_WRITE_SINGLE_REGISTER     6
#define FC_WRITE_MULTIPLE_REGISTERS 16

// MODBUS error codes
#define MOD_NO_ERROR            0
#define MOD_INVALID_FUNC_CODE   1
#define MOD_ADDRESS_ERROR       2
#define MOD_REG_COUNT_ERROR     3
#define MOD_REGISTER_ERROR      4
#define MOD_CRC_ERROR           5
#define MOD_FRAME_ERROR         6

typedef struct
{
  Uint16 msgLength, msgIdx;
  Uint16 buf[MOD_BUF_LENGTH];
}modMsgStruct;

typedef struct
{
  Uint16 state, funcCode, exceptCode, CRC;
  Uint16 modAddr, regAddr, regCount;
  Uint16 frameErrorFlag, msgReceivedFlag;
}modReceiveStruct;

#endif // MODBUS_H_
