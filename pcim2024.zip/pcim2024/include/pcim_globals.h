#ifndef MODBUS_H_
#include "modbus.h"
#endif

#ifndef CDRIVE_IL_GLOBALS_H_
#define CDRIVE_IL_GLOBALS_H_

extern volatile timeStruct time;
extern volatile modMsgStruct msgXmitA, msgRcvA;
extern volatile modReceiveStruct modRcvCtrl;
extern volatile calStruct cal;
extern volatile Uint16 modInputReg[MOD_IR_COUNT];
extern volatile Uint16 modHoldReg[MOD_HR_COUNT];
//extern volatile filter1struct filter1[FLTR1_NUM_CH];
extern volatile filter2struct filter2[FLTR2_NUM_CH];

#endif /* CDRIVE_IL_GLOBALS_H_ */
