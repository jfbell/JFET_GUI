
#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <modbus.h>

void InitVars(void)
{
  unsigned i, j;

  modInputReg[MOD_IR_TOP_STATE]  = SM_INIT;
  modInputReg[MOD_IR_FAULT_CODE] = 0;
  modInputReg[MOD_IR_MINS_TESTED] = 0;
  modInputReg[MOD_IR_TEMP] = 298; // 298 K = 25 degrees C
  modInputReg[MOD_IR_CURRENTx10] = 0;

  modHoldReg[MOD_HR_GUI_FLAG]  = FALSE;
  modHoldReg[MOD_HR_ON_FLAG]   = FALSE;
  modHoldReg[MOD_HR_RESET]     = TRUE;
  modHoldReg[MOD_HR_ILIM]      = 100; // 100 A
  modHoldReg[MOD_HR_STAY_ON]   = 1;  // No timeout
  modHoldReg[MOD_HR_DUR]       = 2;  // Test duration in hours
  modHoldReg[MOD_HR_CAL_T_VAL] = 25; // Default calibration value is 25 degrees C
  modHoldReg[MOD_HR_CAL_T_DUE] = 0;  // GUI will set this when it is ready to calibrate temperature
  cal.zeroCurrentAdcCnt = 0;
  cal.TjMeas = modHoldReg[MOD_HR_CAL_T_VAL];
  cal.TjEntered = modHoldReg[MOD_HR_CAL_T_VAL];
  cal.currentCalDue = TRUE;

  modRcvCtrl.state = MOD_INIT;
  modRcvCtrl.funcCode = 0; modRcvCtrl.exceptCode = MOD_NO_ERROR; modRcvCtrl.CRC = 0;
  modRcvCtrl.regAddr = 0; modRcvCtrl.regCount = 0;
  modRcvCtrl.frameErrorFlag = FALSE; modRcvCtrl.msgReceivedFlag = FALSE;

  time.runCntr = 0;

  for(i = 0; i < FLTR2_NUM_CH; i++)
  {
    for(j = 0; j < 3; j++)
    {
      filter2[i].x[j] = 0;
      filter2[i].y[j] = 0;
    }
  }
}


/* This function configures SCI-A for MODBUS-RTU operation using the TxFIFO and
 * RxFIFO features */
void ConfigSCI_A_MODBUS(void)
{
  Uint16 temp;

  SciaRegs.SCICCR.all = 0x0067;  // 8 bits, idle-line, no loop-back,
                                 // even parity, 1 stop bit, 01100111
  SciaRegs.SCICTL1.all = 0x0043; // Enable Rx & Tx, disable sleep mode,
        // no txwake on xmit, assert software reset, enable rcv error interrupt

  SciaRegs.SCICTL2.all = 0x0002; // Enable Rx/break, disable Tx interrupts

  // Calculate SCIBAUD regs based on desired baud rate and low speed clock
  temp = (LSPCLK_FREQ_Hz / ((long) MOD_BAUD_RATE * 8)) - 1;
  SciaRegs.SCIHBAUD.all = temp >> 8;
  SciaRegs.SCILBAUD.all = temp & 0xFF;

  // Release SCI reset, enable FIFO, reset TxFIFO, clear TxFIFO interrupt
  // Disable TxFIFO interrupt for now.
  // Set TxFifo interrupt level to zero (generate interrupt when FIFO is empty)
  SciaRegs.SCIFFTX.all = 0xC040;

  // Clear FFOVF, reset RxFIFO, clear and enable RxFIFO interrupt, set
  // interrupt level to 1 (generate interrupt for each byte received)
  SciaRegs.SCIFFRX.all = 0x4061;
  SciaRegs.SCIFFCT.all = 0x0; // Disable autobaud detect, no TxFIFO delay
//  SciaRegs.SCIFFTX.all = 0xC000; // Disable SCI reset, enable Tx FIFO, reset TxFIFO,
                                 // FIFO transmit interrupt on FIFO empty, disabled for now

  SciaRegs.SCICTL1.bit.SWRESET = 1;     // Release SCI software reset
  SciaRegs.SCIFFTX.bit.SCIRST = 1;      // Release FIFO SCI reset
  SciaRegs.SCIFFTX.bit.TXFIFORESET = 1; // Release FIFO transmit reset
  SciaRegs.SCIFFRX.bit.RXFIFORESET = 1; // Release FIFO receive reset

  // Complete current rcv, xmit sequence before stopping at breakpoints
  SciaRegs.SCIPRI.bit.FREESOFT = 1;
}


void ConfigADC()
{
  EALLOW;
  AnalogSubsysRegs.AGPIOCTRLH.bit.GPIO224 = 1; // Connect GPIO224 pin to analog system
  AnalogSubsysRegs.ANAREFCTL.bit.ANAREFSEL = 0; // Use internal reference
  AnalogSubsysRegs.ANAREFCTL.bit.ANAREF2P5SEL = 0; // Use 3.3V internal reference3

  // Sample width = 15 + 1 clocks = 267 ns
  // Conversion time = 13 clocks = 217 ns
  // With 60 MHz clock, total time = 483 ns
  AdcaRegs.ADCSOC0CTL.bit.ACQPS = 0x1FF; // 15;
  AdcaRegs.ADCSOC1CTL.bit.ACQPS = 0x1FF;

  // Select the channel to be converted when SOCx is received
  AdcaRegs.ADCSOC0CTL.bit.CHSEL = 1;  // A1 - current
  AdcaRegs.ADCSOC1CTL.bit.CHSEL = 2;  // A2 - temperature

  // Select the triggers
  AdcaRegs.ADCSOC0CTL.bit.TRIGSEL = 0;   // Disable trigger, use software force
  AdcaRegs.ADCSOC1CTL.bit.TRIGSEL = 0;

  // Setup control registers
  AdcaRegs.ADCCTL1.bit.ADCPWDNZ = 1;     // Power up the ADC
  AdcaRegs.ADCCTL1.bit.INTPULSEPOS = 1;  // Interrupt set at end of conversion

  AdcaRegs.ADCINTSEL1N2.bit.INT1SEL = 1; // SOC1 is trigger for ADCINT1
  AdcaRegs.ADCINTSEL1N2.bit.INT1E = 1;   // Enable INT1
  EDIS;

  AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; // Clear overflow flag
  AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; // Clear ADCINT flag
}
