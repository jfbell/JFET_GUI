/* File: cdrive_IL_main.c
*  Original author: Jonathan Dodge
*  Revision     Date
*    Rev. 1.0   5 December 2023
*      Initial release
*    Rev. 1.1  23 January 2024
*      Added temperature sense
*    Rev. 1.2  30 January 2024
*      Updated temperature equation factors in hbridge_IL_process.c
*      Change temperature sense equation
*    Rev. 1.3  31 January 2024
*      Debugged ADC (was off, and using external reference)
*      Changed PWM outputs from PWM1a and 2a to PWM3a and 4a because Q1 and Q3
*      (high-side) gate drive traces are swapped on the board.
*    Rev. 1.4   1 February 2024
*      Turned PWM1a and 2a back on and kept them duplicated to PWM3a and 4a.
*    Rev. 1.5   5 February 2024
*      Reduced deadtime to 100 ns
*    Rev. 1.6   6 February 2024
*      Added deadtime control through GUI
*      Changed switching frequency to update in both STOP and IDLE states
*
*  Description:
*    This is the top-level program file for the H-bridge trade show demo
*    board.  This program runs on a TMS320F2800137 control card that connects
*    to the board.  The full-bridge is driven with sine-triangle PWM
*    modulation.  The modulation depth, fundamental frequency, and
*    switching frequency are set by a GUI.  Over-modulation is not supported.
*    The command vector angle is updated in the timer0 ISR.
*
*    Parameters are selected through the GUI communicating
*    by SCI through the XDS110 emulator on the control card, which appears as
*    a COM port to the host PC although the actual connection is by USB cable.
*    Timer1 handles the MODBUS-RTU time delimination and coordinates a state
*    machine with SCI-A FIFO interrupt service routines.
*/

#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <modbus.h>

// Prototype statements for functions found within this file.
interrupt void cpu_timer0_isr(void);
interrupt void cpu_timer1_isr(void);
interrupt void sciaTxFifoIsr(void);
interrupt void sciaRxFifoIsr(void);
void ConfigSCI_A_MODBUS(void);
void ConfigADC(void);
void InitVars(void);
void InitModComm(void);
void UpdateModbus(Uint16 commChannel);
void ProcessModbusCommands(void);
void CheckLimits(void);

void main(void)
{
  Uint16 i, j;

  // Initialize System Control:
  // PLL, disable WatchDog, enable peripheral clocks
  InitSysCtrl();

  // Initialize GPIO:
  GpioDataRegs.GPADAT.all = 0x01000000; // LED2 (GUI sync) off, debug off, gates off
  MODE_LED_OFF;
  EALLOW;
  GpioCtrlRegs.GPAAMSEL.all = 0;        // Disable analog functions from all analog/digital pins
  GpioCtrlRegs.GPADIR.all = 0x21001001; // GPIO[0] = JFET control
                                        // GPIO[1:11] = unused
                                        // GPIO[12] = debug output for triggering
                                        // GPIO[13:23] = unused
                                        // GPIO[24] = LED1 'GUI sync'
                                        // GPIO[25:27] = unused
                                        // GPIO28 = SCIRXDA, input
                                        // GPIO29 = SCITXDA, output
                                        // GPIO[30:31] = unused
  GpioCtrlRegs.GPAMUX1.all = 0;
  GpioCtrlRegs.GPBDIR.bit.GPIO39 = 1;   // GPIO39 = LED3 'mode'
  GpioCtrlRegs.GPAPUD.all = 0x01001001; // Disable pullups on gate control pins, debug
  GpioCtrlRegs.GPBPUD.bit.GPIO39   = 1; // Disable pullup on GPIO39
  GpioCtrlRegs.GPAMUX2.bit.GPIO28  = 1; // Connect SCIRXDA to GPIO28
  GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3; // Set to asynchronous input
  GpioCtrlRegs.GPAMUX2.bit.GPIO29  = 1; // Connect SCITXDA to GPIO29
  GpioCtrlRegs.GPHAMSEL.bit.GPIO224 = 1; // Disconnect analog/digital pin from GIPO (default)
  EDIS;

  // Copy time-critical code and FLASH setup code to RAM
  // The  RamfuncsLoadStart, RamfuncsLoadEnd, and RamfuncsRunStart
  // symbols are created by the linker. Refer to the 28335.cmd file.
#ifdef _FLASH
  memcpy(&RamfuncsRunStart, &RamfuncsLoadStart, (size_t)&RamfuncsLoadSize);

  // Call Flash Initialization to setup flash wait states
  // This function must reside in RAM
  InitFlash(); // Found in sysCtrl.c
#endif

  // Clear all interrupts and initialize PIE vector table:
  // Disable CPU interrupts
  DINT;

  // All PIE interrupts disabled and flags cleared (default state)
  InitPieCtrl();
  IER = 0x0000;
  IFR = 0x0000;
  InitPieVectTable();

  // Map ISR functions
  EALLOW;
  PieVectTable.TIMER0_INT = &cpu_timer0_isr;
  PieVectTable.TIMER1_INT = &cpu_timer1_isr;
  PieVectTable.SCIA_TX_INT = &sciaTxFifoIsr;
  PieVectTable.SCIA_RX_INT = &sciaRxFifoIsr;
  EDIS;

  // Initialize variables
  InitVars();

  ConfigADC();

  // Initialize all three CPU timers to a known state (stopped, no interrupt)
  InitCpuTimers();
  // Set prescale divide by 1 (timer clock = SYSCLKOUT)
  CpuTimer0Regs.TPR.all  = 0;
  CpuTimer0Regs.TPRH.all = 0;
  CpuTimer1Regs.TPR.all  = 0;
  CpuTimer1Regs.TPRH.all = 0;

  CpuTimer0.CPUFreqInMHz = CPU_FREQ_MHz;
  CpuTimer0.PeriodInUSec = TIMER0_PERIOD * 1000000;
  CpuTimer0Regs.PRD.all = (long)(CpuTimer0.CPUFreqInMHz * CpuTimer0.PeriodInUSec);
  CpuTimer0.InterruptCount = 0;
  CpuTimer1.CPUFreqInMHz = CPU_FREQ_MHz;
  CpuTimer1.PeriodInUSec = T1_3P5_TIME; //timer1 checks for idle line >= 3.5 bytes long
  CpuTimer1Regs.PRD.all = (long)(CpuTimer1.CPUFreqInMHz * CpuTimer1.PeriodInUSec);
  CpuTimer1.InterruptCount = 0;

  // Initialize timer control register
  CpuTimer0Regs.TCR.all = 0xC020; // Clear IF, enable int, load period, start
  CpuTimer1Regs.TCR.all = 0x8010; // Clear IF, disable int, timer stopped

  // Configure SCI-A for MODBUS comm
  ConfigSCI_A_MODBUS();
  InitModComm();

  // Enable interrupts
  PieCtrlRegs.PIEIER1.bit.INTx7 = 1;  // Enable TINT0 (Timer0)
  PieCtrlRegs.PIEIER9.bit.INTx1 = 1;  // PIE Group 9, SCIRXINTA
  PieCtrlRegs.PIEIER9.bit.INTx2 = 1;  // PIE Group 9, SCITXINTA
  PieCtrlRegs.PIECTRL.bit.ENPIE = 1;  // Vectors (except reset) are taken from the PIE table
  PieCtrlRegs.PIEACK.all = 0xFFFF;    // Clear any spurious PIE ack flags

  IER |= M_INT1;  // Connected to Timer0, ADC
  IER |= M_INT13; // Connected to Timer1
  IER |= M_INT9;  // Connected to SCI-A

  // Enable global Interrupts and higher priority real-time debug events:
  EINT;   // Enable Global interrupt INTM
  ERTM;   // Enable Global realtime interrupt DBGM

  // Initialize SCI-A for MODBUS comm
  j = SciaRegs.SCIFFRX.bit.RXFFST;
  for(i = 0; i < j; i++)
  { // Empty the FIFO using msgRcvA.buf[0] as temp storage
    msgRcvA.buf[0] = SciaRegs.SCIRXBUF.all;
  }
  msgRcvA.buf[0] = 0;

  // Start timer1 to check for idle Rx line at least 3.5 bytes long
  CpuTimer1Regs.TCR.all = 0xC020; // Clear IF, enable int, load period, start

  // Start AD conversion
    AdcaRegs.ADCSOCFRC1.bit.SOC0 = 1; // Start AD conversion
    AdcaRegs.ADCSOCFRC1.bit.SOC1 = 1;

  // Main while loop
  while(1)
  {
    // Trigger the ADC
    if(AdcaRegs.ADCINTOVF.bit.ADCINT1 == 1) //ADCINT overflow occurred
    {
      AdcaRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //Clear overflow flag
      AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //Re-clear ADCINT flag
    }
    else if(AdcaRegs.ADCINTFLG.bit.ADCINT1 == 1)
    {
      filter2[CURRENT_FLTR].x[0] = ADCRES_CURRENT;
      filter2[TJ_FLTR].x[0] = ADCRES_TJ;
      AdcaRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag for ADC-A
      AdcaRegs.ADCSOCFRC1.bit.SOC0 = 1; // Start AD conversion
      AdcaRegs.ADCSOCFRC1.bit.SOC1 = 1;
    }

      UpdateModbus(SCI_A); // Update serial communication
      ProcessModbusCommands();
      CheckLimits();       // Perform limit checking on analog channels
  } // End of main loop
} // End of main()

void CheckLimits(void)
{
  float clTempFloat;

  if(cal.zeroCurrentAdcCnt > filter2[CURRENT_FLTR].y[2])
    clTempFloat = (float)cal.zeroCurrentAdcCnt - filter2[CURRENT_FLTR].y[2];
  else
    clTempFloat = filter2[CURRENT_FLTR].y[2] - (float)cal.zeroCurrentAdcCnt;

  modInputReg[MOD_IR_CURRENTx10] = (unsigned)(clTempFloat * AMPS_PER_COUNTx10);
  if(modInputReg[MOD_IR_TOP_STATE] != SM_INIT)
  {
    if(modInputReg[MOD_IR_CURRENTx10] > (modHoldReg[MOD_HR_ILIM] * 10))
    {
      modInputReg[MOD_IR_FAULT_CODE] |= 0x01; // Overcurrent
    }
  }

  // Tj algorithm: Subtract calibrated ADC value from present ADC value
  // Calculate delta T in degrees K
  // Add delta T to calibration value
  clTempFloat = filter2[TJ_FLTR].y[2] - (float)cal.TjMeas;
  clTempFloat *= DEG_PER_COUNT;
  clTempFloat += cal.TjEntered;
  if((clTempFloat > 0) && (modInputReg[MOD_IR_TOP_STATE] == SM_ON))
    modInputReg[MOD_IR_TEMP] = (unsigned)clTempFloat;
}
