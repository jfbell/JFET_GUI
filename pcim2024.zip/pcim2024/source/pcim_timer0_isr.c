/* This file contains the timer0 ISR
 */
#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <modbus.h>
#include <math.h>

#ifdef _FLASH
#pragma CODE_SECTION(cpu_timer0_isr, ".TI.ramfunc");
#endif

interrupt void cpu_timer0_isr(void)
{
  unsigned i;

  //********** First order filters **********
  // Filter raw commanded current magnitude
  // 0.33 tau, 10000 Hz sample first-order filter of magRaw
/*  for(i = 0; i < FLTR1_NUM_CH; i++)
  {
    filter1[i].y[0] = 0.00015  * filter1[i].x[1]
                + 0.00015   * filter1[i].x[0]
                - (-0.9997) * filter1[i].y[1];

    filter1[i].x[1] = filter1[i].x[0];
    filter1[i].y[1] = filter1[i].y[0]; // x[0] takes dirty input, y[0] stores the "clean" output value
  } */

  // ***** IIR2 "Butterworth" filter, 800 Hz corner freq, 10 kHz sample rate **
/*  for(i = 0; i < FLTR2_NUM_CH; i++)
  {
    filter2[i].x[0] = *(&AdcaResultRegs.ADCRESULT0 + i); // ADC and filter channel indexes align
    filter2[i].y[0] = 0.0445 * filter2[i].x[2]
                    + 0.0891 * filter2[i].x[1]
                    + 0.0445 * filter2[i].x[0]
                    - 0.4989 * filter2[i].y[2]
                    - (-1.3208) * filter2[i].y[1];

    filter2[i].x[2] = filter2[i].x[1];
    filter2[i].x[1] = filter2[i].x[0];
    filter2[i].y[2] = filter2[i].y[1];
    filter2[i].y[1] = filter2[i].y[0]; // x[0] takes dirty input, y[0] stores the "clean" output value
  } */

  // ***** IIR2 "Butterworth" filter, 80 Hz corner freq, 10 kHz sample rate **
  for(i = 0; i < FLTR2_NUM_CH; i++)
  {
    filter2[i].x[0] = *(&AdcaResultRegs.ADCRESULT0 + i); // ADC and filter channel indexes align
    filter2[i].y[0] = 0.0006 * filter2[i].x[2]
                    + 0.0012 * filter2[i].x[1]
                    + 0.0006 * filter2[i].x[0]
                    - 0.9314 * filter2[i].y[2]
                    - (-1.929) * filter2[i].y[1];

    filter2[i].x[2] = filter2[i].x[1];
    filter2[i].x[1] = filter2[i].x[0];
    filter2[i].y[2] = filter2[i].y[1];
    filter2[i].y[1] = filter2[i].y[0]; // x[0] takes dirty input, y[0] stores the "clean" output value
  }

  //********** Heartbeat timer stuff **********
  CpuTimer0.InterruptCount++;
  if(CpuTimer0.InterruptCount >= 0.001 / TIMER0_PERIOD)
  {
    time.millisecond++;
    CpuTimer0.InterruptCount = 0;

    if((time.millisecond % 500) == 0)
    {
      if(modInputReg[MOD_IR_TOP_STATE] == SM_ON)
      {
        MODE_LED_TOGGLE;
        time.runCntr++; // Increments every half-second
        if(time.runCntr >= 120) // 120 half-seconds per minute
        {
          modInputReg[MOD_IR_MINS_TESTED]++;
          time.runCntr = 0;
        }
      }

      time.halfSecond++;
      if(time.halfSecond >= 2)
      {
        time.millisecond = 0;
        time.halfSecond = 0;
      }
    }
  }

  // Acknowledge this interrupt to receive more interrupts from group 1
  PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}
