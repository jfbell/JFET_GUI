/*
* sci_isr.c
*
*  Created on: 23 December 2016
*      Author: Jonathan Dodge
*
* Content: Serial communication interface transmit and receive ISRs
* Description:
*   MODBUS server (slave) driver code.
*   The transmit ISR automatically sends a string of bytes stored in its data
*   structure.
*   The receive ISR works in conjunction with timer1 to follow a MODBUS_RTU
*   slave state machine with time-delimited packets.  The incoming message is
*   stored and prepared it for processing, which actually happens during
*   response transmission.
*
*   The non-error states in the receive state machine transition as follows:
*     MOD_INIT: wait for 3.5 byte time to elapse, reset timer if a byte is
*       received in the meantime and ignore byte
*     MOD_IDLE: upon receipt of first byte, store and start 1.5 and 3.5 byte
*       timer
*     MOD_RECEIVE: upon receipt of each byte, store and restart 1.5 and 3.5
*       byte timer until 1.5 byte timer expires
*     MOD_CTRL_WAIT: if CRC is OK then frame flag = OK, wait until 3.5 byte
*       time expires; if CRC is not OK then treat as frame error and ignore
*       message and restart 3.5 byte timer for any further received bytes; in
*       either case go back to MOD_IDLE after 3.5 byte time expires
*/

#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <modbus.h>

#ifdef _FLASH
#pragma CODE_SECTION(sciaRxFifoIsr, ".TI.ramfunc");
#pragma CODE_SECTION(sciaTxFifoIsr, ".TI.ramfunc");
#endif

// Function prototypes
int CheckAddrAndFC(Uint16);
int CheckStartAddr(Uint16, Uint16);
void ResetModReceive(void);
void ResetModTransmit(void);
Uint16 ComputeCRC(volatile modMsgStruct *msg, Uint16 modFrameLength);

interrupt void sciaTxFifoIsr(void)
{
  unsigned i;
  if(msgXmitA.msgLength > 0)
  {
    for(i = 0; i < msgXmitA.msgLength; i++)
    {
        SciaRegs.SCITXBUF.all = msgXmitA.buf[msgXmitA.msgIdx]; // Store byte in xmit FIFO
        msgXmitA.msgIdx++;

      if(msgXmitA.msgIdx == msgXmitA.msgLength)
      {
        // strIdx gives count of characters sent; must be set to zero before sending string
        SciaRegs.SCIFFTX.bit.TXFFIENA = 0; // Disable further interrupts
        break;
      }

      // If the FIFO is full, continue filling it on the next interrupt to
      // avoid overflowing it
      if(i >= SCI_FIFO_FULL_CNT)
        break;
    }
  }
  else
  {  // If there is nothing to do we got here by mistake.
    ResetModTransmit(); // Resets data structure, disables further interrupts
  }
//SciaRegs.SCIFFTX.bit.TXFFIENA = 0; // Suspend further interrupts
  SciaRegs.SCIFFTX.bit.TXFFINTCLR = 1; // Clear SCI Interrupt flag
  PieCtrlRegs.PIEACK.bit.ACK9 = 1;  // Issue PIE acknowledge
}


/* This ISR processes incoming messages from the host (MODBUS master).  All
 * messages use MODBUS-RTU protocol, meaning all data are binary.  Message
 * frames are time-delimited using timer1.  Upon receipt of a message, flags
 * are set in the modbus control data structure to indicate whether successful
 * so the top-level MODBUS functions can process the message.
 */
interrupt void sciaRxFifoIsr(void)
{
  Uint16 i, j;
  // Check for comm errors
  if((SciaRegs.SCIRXST.bit.RXERROR) || (SciaRegs.SCIFFRX.bit.RXFFOVF))
  {
    modRcvCtrl.frameErrorFlag = TRUE;
    modRcvCtrl.exceptCode = MOD_FRAME_ERROR;
  }
  else if(modRcvCtrl.state == MOD_INIT)
  { // Getting here means we received a byte.  We ignore the byte and restart
    // the t3.5 timer
    j = SciaRegs.SCIFFRX.bit.RXFFST;
    for(i = 0; i < j; i++)
    { // Empty the FIFO using msgRcvA.buf[0] as temp storage
      msgRcvA.buf[0] = SciaRegs.SCIRXBUF.all;
    }
    msgRcvA.buf[0] = 0;

    CpuTimer1.PeriodInUSec = T1_3P5_TIME;
    CpuTimer1Regs.PRD.all = (long) CPU_FREQ_MHz * CpuTimer1.PeriodInUSec;
  }
  else if(modRcvCtrl.state == MOD_IDLE)
  {
    // Store byte(s)
    j = SciaRegs.SCIFFRX.bit.RXFFST;
    msgRcvA.msgIdx = 0;
    msgRcvA.msgLength = 0;
    for(i = 0; i < j; i++)
    {
      msgRcvA.buf[msgRcvA.msgIdx++] = SciaRegs.SCIRXBUF.all;
      msgRcvA.msgLength++;
    }

    // Start t1.5 timer
    CpuTimer1.PeriodInUSec = T1_1P5_TIME;
    CpuTimer1Regs.PRD.all = (long) CPU_FREQ_MHz * CpuTimer1.PeriodInUSec;

    modRcvCtrl.state = MOD_RECEIVE; // Move to receive state
  }
  else if(modRcvCtrl.state == MOD_RECEIVE)
  {
    // Store byte(s)
    j = SciaRegs.SCIFFRX.bit.RXFFST;
    for(i = 0; i < j; i++)
    {
      msgRcvA.buf[msgRcvA.msgIdx++] = SciaRegs.SCIRXBUF.all;
      msgRcvA.msgLength++;
    }

    // Restart t1.5 timer
    CpuTimer1.PeriodInUSec = T1_3P5_TIME;
    CpuTimer1Regs.PRD.all = (long) CPU_FREQ_MHz * CpuTimer1.PeriodInUSec;
  }
  else if(modRcvCtrl.state == MOD_CTRL_WAIT)
  { // Getting here means an unexpected byte arrived after a pause
    CpuTimer1.PeriodInUSec = T1_3P5_TIME;
    modRcvCtrl.frameErrorFlag = TRUE;
    modRcvCtrl.exceptCode = MOD_FRAME_ERROR;
    modRcvCtrl.state = MOD_INIT;
  }

  SciaRegs.SCIFFRX.bit.RXFFINTCLR = 1;
  PieCtrlRegs.PIEACK.bit.ACK9 = 1;  // Issue PIE acknowledge
  CpuTimer1Regs.TCR.all = 0xC020; // Clear IF, enable int, load period, start
}


// This function checks for the assigned slave address and function code from
// the master.  If both are valid, return the function code.
int CheckAddrAndFC(Uint16 addrAndCode)
{
  Uint16 paTemp;
  int paReturnVal;

  paTemp = (addrAndCode & 0xFF00) >> 8;  // Check for address
  if(paTemp != MODBUS_ADDRESS)
  {
    return(0);  // Not our address so ignore message, no error
  }

  paTemp = addrAndCode & 0x00FF; // Check for function code

  switch(paTemp)
  {
    case FC_READ_HOLD_REGISTERS :
    case FC_READ_INPUT_REGISTERS :
    case FC_WRITE_SINGLE_REGISTER :
    case FC_WRITE_MULTIPLE_REGISTERS :
      paReturnVal = paTemp;
      break;

    default:
      paReturnVal = -1; // Not a valid function code, so indicate error
      break;
  }
    return(paReturnVal);
} //end of ParseAddrAndCode()
