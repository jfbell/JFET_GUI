#include <include/pcim.h>
#include <modbus.h>

volatile timeStruct time;
volatile modMsgStruct msgXmitA, msgRcvA;
volatile modReceiveStruct modRcvCtrl;
volatile calStruct cal;
volatile Uint16 modInputReg[MOD_IR_COUNT];
volatile Uint16 modHoldReg[MOD_HR_COUNT];
//volatile filter1struct filter1[FLTR1_NUM_CH];
volatile filter2struct filter2[FLTR2_NUM_CH];
