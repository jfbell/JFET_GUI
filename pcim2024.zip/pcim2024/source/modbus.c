/*
 * modbus.c
 *
 *  Created on: 22 December 2016
 *      Author: Jonathan Dodge
 *  Description:
 *  This file contains code for all MODBUS communications.  Only the SCI-A port
 *  is used in this application.  The serial protocol used is MODBUS-RTU, based
 *  on the MODBUS Application Protocol Specification V1.1b3, and MODBUS Over
 *  Serial Line Specification and Implementation Guide V1.02, both available
 *  from www.modbus.org
 *
 *  Supported MODBUS function codes include:
 *    Code   Name
 *     3     Read holding registers
 *     4     Read input registers
 *     6     Write single register
 *    16     Write multiple registers
 *
 * Values from the test state machine and ADC are stored in the global array
 * modInputReg[].  Values that control the operation of the test are received
 * from the host computer (MODBUS master) and stored in the global array
 * modHoldReg[].  The definitions of the contents of each register in these
 * arrays are defined in NPC3L_pt_modbus.h.
 *
 * The sequence of events is as follows.  The master sends a command, and its
 * receipt through the SCI-A peripheral is handled automatically by the SCI
 * FIFO receive ISR; with data from the master (if any) stored in the
 * appropriate modHoldReg[] registers.  The function code and other info are
 * stored in a MODBUS control data structure by the SCI FIFO receive ISR.  The
 * function UpdateModbus(), called in main(), calls ReadModRegs(),
 * WriteModReg(), or WriteModRegs(), depending on the function code received
 * from the master.  In each of these functions, data are arranged in MODBUS
 * message and control data structures.  Upon successful completion of these
 * functions, the SCI transmit FIFO interrupt is enabled, and data are sent
 * automatically to the master by the SCI transmit FIFO ISR.  Finally, the
 * function ProcessModbusCommands() is called from main, which launches certain
 * actions based on "commands" stored in certain modHoldReg[] registers.
 *
 * Updated 4 December 2023 adding reset in the event of RXERROR
 */

#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <modbus.h>

#ifdef _FLASH
#pragma CODE_SECTION(cpu_timer1_isr, ".TI.ramfunc");
#endif

Uint16 ReadModRegs(void);
Uint16 WriteModReg(void);
Uint16 WriteModRegs(void);
Uint16 ComputeCRC(volatile modMsgStruct *msg, Uint16 modFrameLength);
void ResetModReceive(Uint16);
void ResetModTransmit(Uint16);

void UpdateModbus(Uint16 commChannel)
{
  Uint16 wsrCRC;

  if(commChannel == SCI_A)
  {
    // Check for comm errors
    if((modRcvCtrl.frameErrorFlag) || (SciaRegs.SCIFFRX.bit.RXFFOVF))
    {
      ResetModReceive(SCI_A);
    }
    else if((modRcvCtrl.state == MOD_IDLE) && (modRcvCtrl.msgReceivedFlag))
    {
      modRcvCtrl.msgReceivedFlag = FALSE; // Message being processed, so reset flag

      // Only respond if we are being addressed
      if(modRcvCtrl.modAddr == MODBUS_ADDRESS)
      {
        // Process function code
        switch(modRcvCtrl.funcCode)
        {
          case FC_READ_HOLD_REGISTERS:
            msgXmitA.msgLength = ReadModRegs();
            break;

          case FC_READ_INPUT_REGISTERS:
            msgXmitA.msgLength = ReadModRegs();
            break;

          case FC_WRITE_SINGLE_REGISTER:
            msgXmitA.msgLength = WriteModReg();
            break;

          case FC_WRITE_MULTIPLE_REGISTERS:
            msgXmitA.msgLength = WriteModRegs();
            break;

          // Not a valid function code, maybe out of sync
          default:
            msgXmitA.msgLength = 0;
            break;
        }

        if(msgXmitA.msgLength == 0) // Command is not valid
        {
            // Formulate error response
          ResetModTransmit(SCI_A);
          msgXmitA.buf[0] = MODBUS_ADDRESS;
          msgXmitA.buf[1] = modRcvCtrl.funcCode + 0x80;
          msgXmitA.buf[2] = MOD_INVALID_FUNC_CODE; // Illegal function code
          wsrCRC = ComputeCRC(&msgXmitA, 3);
          msgXmitA.buf[4] = (wsrCRC & 0xFF00) >> 8;
          msgXmitA.buf[3] = wsrCRC & 0x00FF;
          msgXmitA.msgLength = 5;
        }

        // Enable xmit FIFO to send response
        msgXmitA.msgIdx = 0; // Must be set to zero before sending string
        SciaRegs.SCIFFTX.bit.TXFFIENA = 1; // Enable xmit FIFO interrupt
      }
    }
  }
}


Uint16 ReadModRegs(void)
{
  Uint16 rrCRC, i;

  // Extract register address from incoming message
  modRcvCtrl.regAddr = ((msgRcvA.buf[2] & 0x00FF) << 8) |
                           (msgRcvA.buf[3] & 0x00FF);
  modRcvCtrl.regCount = ((msgRcvA.buf[4] & 0x00FF) << 8) |
                         (msgRcvA.buf[5] & 0x00FF);

  // Check if data and register address are within range
  if(modRcvCtrl.funcCode == FC_READ_HOLD_REGISTERS)
  {
    if((modRcvCtrl.regCount >= 1) && (modRcvCtrl.regCount <= MOD_HR_COUNT))
    {
      if((modRcvCtrl.regAddr + modRcvCtrl.regCount) <= MOD_HR_COUNT)
        modRcvCtrl.exceptCode = MOD_NO_ERROR;
      else
        modRcvCtrl.exceptCode = MOD_ADDRESS_ERROR;
    }
    else
      modRcvCtrl.exceptCode = MOD_REG_COUNT_ERROR;
  }
  else // Assuming at this point the function code is to read input registers
  {
    if((modRcvCtrl.regCount >= 1) && (modRcvCtrl.regCount <= MOD_IR_COUNT))
    {
      if((modRcvCtrl.regAddr + modRcvCtrl.regCount) <= MOD_IR_COUNT)
        modRcvCtrl.exceptCode = MOD_NO_ERROR;
      else
        modRcvCtrl.exceptCode = MOD_ADDRESS_ERROR;
    }
    else
      modRcvCtrl.exceptCode = MOD_REG_COUNT_ERROR;
  }

  if(modRcvCtrl.exceptCode == MOD_NO_ERROR)
  {
    // Formulate normal response message
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode;
    msgXmitA.buf[2] = 2 * modRcvCtrl.regCount; // Byte count

    if(modRcvCtrl.funcCode == FC_READ_HOLD_REGISTERS)
    {
      for(i = 0; i < modRcvCtrl.regCount; i++)
      {
        msgXmitA.buf[3 + 2 * i] = (modHoldReg[modRcvCtrl.regAddr + i] & 0xFF00) >> 8;
        msgXmitA.buf[4 + 2 * i] = (modHoldReg[modRcvCtrl.regAddr + i] & 0x00FF);
      }
    }
    else // Assume FC is read input registers
    {
      for(i = 0; i < modRcvCtrl.regCount; i++)
      {
        msgXmitA.buf[3 + 2 * i] = (modInputReg[modRcvCtrl.regAddr + i] & 0xFF00) >> 8;
        msgXmitA.buf[4 + 2 * i] = (modInputReg[modRcvCtrl.regAddr + i] & 0x00FF);
      }
    }

    rrCRC = ComputeCRC(&msgXmitA, 2 * modRcvCtrl.regCount + 3);
    msgXmitA.buf[3 + 2 * i] = rrCRC & 0x00FF;
    msgXmitA.buf[4 + 2 * i] = (rrCRC & 0xFF00) >> 8;
    return(2 * modRcvCtrl.regCount + 5);
  }
  else
  { // Data or register address was out of range, so formulate error response
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode + 0x80;
    msgXmitA.buf[2] = modRcvCtrl.exceptCode;
    rrCRC = ComputeCRC(&msgXmitA, 3);
    msgXmitA.buf[3] = rrCRC & 0x00FF;
    msgXmitA.buf[4] = (rrCRC & 0xFF00) >> 8;
    return(5);
  }
}

// This function writes a single register with data from the master
Uint16 WriteModReg(void)
{
  Uint16 wsrCRC, i;

  // Extract register address from incoming message
  modRcvCtrl.regAddr = ((msgRcvA.buf[2] & 0x00FF) << 8) |
                           (msgRcvA.buf[3] & 0x00FF);

  // Write data to addressed holding register if address is within range
  if(modRcvCtrl.regAddr <= (MOD_HR_COUNT - 1))
  {
    modHoldReg[modRcvCtrl.regAddr] = ((msgRcvA.buf[4] & 0x00FF) << 8) |
                           (msgRcvA.buf[5] & 0x00FF);

    // Formulate normal response message
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode;
    for(i = 2; i < 6; i++)
    {
      msgXmitA.buf[i] = msgRcvA.buf[i];
    }
    wsrCRC = ComputeCRC(&msgXmitA, 6);
    msgXmitA.buf[6] = wsrCRC & 0x00FF;
    msgXmitA.buf[7] = (wsrCRC & 0xFF00) >> 8;
    return(8);
  }
  else
  { // Data address was out of range, so formulate error response
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode + 0x80;
    msgXmitA.buf[2] = MOD_ADDRESS_ERROR; // exception code for illegal data address (code 2)
    wsrCRC = ComputeCRC(&msgXmitA, 3);
    msgXmitA.buf[3] = wsrCRC & 0x00FF;
    msgXmitA.buf[4] = (wsrCRC & 0xFF00) >> 8;
    return(5);
  }
}

// This function writes multiple registers with data from the master
Uint16 WriteModRegs(void)
{
  Uint16 wmrCRC, i;

  // Extract register address from incoming message
  modRcvCtrl.regAddr = ((msgRcvA.buf[2] & 0x00FF) << 8) |
                           (msgRcvA.buf[3] & 0x00FF);
  modRcvCtrl.regCount = ((msgRcvA.buf[4] & 0x00FF) << 8) |
                         (msgRcvA.buf[5] & 0x00FF);

  // Check if data and register address are within range
  if((modRcvCtrl.regCount >= 1) && (modRcvCtrl.regCount <= MOD_HR_COUNT))
  {
    if((modRcvCtrl.regCount + modRcvCtrl.regAddr) <= MOD_HR_COUNT)
      modRcvCtrl.exceptCode = MOD_NO_ERROR;
    else
      modRcvCtrl.exceptCode = MOD_ADDRESS_ERROR;
  }
  else
    modRcvCtrl.exceptCode = MOD_REG_COUNT_ERROR;

  if(modRcvCtrl.exceptCode == MOD_NO_ERROR)
  {// Write data to addressed holding registers
    for(i = 0; i < modRcvCtrl.regCount; i++)
    {
      modHoldReg[modRcvCtrl.regAddr + i] = ((msgRcvA.buf[7 + 2 * i] & 0x00FF) << 8) |
                                 (msgRcvA.buf[8 + 2 * i] & 0x00FF);
    }

    // Formulate normal response message
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode;
    for(i = 2; i < 6; i++)
    {
      msgXmitA.buf[i] = msgRcvA.buf[i];
    }
    wmrCRC = ComputeCRC(&msgXmitA, 6);
    msgXmitA.buf[6] = wmrCRC & 0x00FF;
    msgXmitA.buf[7] = (wmrCRC & 0xFF00) >> 8;
    return(8);
  }
  else
  { // Data or register address was out of range, so formulate error response
    msgXmitA.buf[0] = MODBUS_ADDRESS;
    msgXmitA.buf[1] = modRcvCtrl.funcCode + 0x80;
    msgXmitA.buf[2] = modRcvCtrl.exceptCode;
    wmrCRC = ComputeCRC(&msgXmitA, 3);
    msgXmitA.buf[3] = wmrCRC & 0x00FF;
    msgXmitA.buf[4] = (wmrCRC & 0xFF00) >> 8;
    return(5);
  }
}


void InitModComm(void)
{
//  SciaRegs.SCIFFTX.bit.TXFFIENA = 0; // Disable transmit FIFO interrupts
  msgXmitA.msgLength = 0;
  msgXmitA.msgIdx = 0;
  msgRcvA.msgLength = 0;
  msgRcvA.msgIdx = 0;

  modRcvCtrl.state = MOD_INIT; // Look for address match and function code from host
  modRcvCtrl.funcCode = 0;
  modRcvCtrl.exceptCode = MOD_NO_ERROR;
  modRcvCtrl.frameErrorFlag = FALSE;
}


void ResetModTransmit(Uint16 channel)
{
  if(channel == SCI_A)
  {
    SciaRegs.SCIFFTX.bit.TXFIFORESET = 0;  // Reset transmitter
    SciaRegs.SCIFFTX.bit.TXFFIENA = 0; // Disable transmit FIFO interrupts
    msgXmitA.msgLength = 0;
    msgXmitA.msgIdx = 0;
    SciaRegs.SCIFFTX.bit.TXFIFORESET = 1;
  }
}


void ResetModReceive(Uint16 channel)
{
  Uint16 i;

  if(channel == SCI_A)
  {
    SciaRegs.SCIFFRX.bit.RXFIFORESET = 0; // Reset the RxFIFO
    SciaRegs.SCIFFRX.bit.RXFFOVRCLR = 1;  // Clear FIFO overflow flag (whether set or not)
    SciaRegs.SCIFFRX.bit.RXFFINTCLR = 1;  // Clear FIFO receive interrupt (whether set or not)

    // A receive error requires a SCI software reset
    if(SciaRegs.SCIRXST.bit.RXERROR)
    {
      SciaRegs.SCICTL1.bit.SWRESET = 0;
    }

    msgRcvA.msgLength = 0;
    msgRcvA.msgIdx = 0;

    modRcvCtrl.state = MOD_INIT; // Look for address match and function code from host
    modRcvCtrl.funcCode = 0;
    modRcvCtrl.exceptCode = MOD_NO_ERROR;
    modRcvCtrl.frameErrorFlag = FALSE;

    for(i = 0; i < MOD_BUF_LENGTH; i++)
      msgRcvA.buf[i] = 0;

    SciaRegs.SCIFFRX.bit.RXFIFORESET = 1; // Release RxFIFO reset
    SciaRegs.SCICTL1.bit.SWRESET = 1;     // Release software reset (in case it was active)
  }
}


interrupt void cpu_timer1_isr(void)
{
  if(modRcvCtrl.state == MOD_INIT)
  { // Getting here means the Rx line was idle at least t3.5
    CpuTimer1Regs.TCR.all = 0x8010; // Clear IF, disable interrupt, stop timer
    modRcvCtrl.state = MOD_IDLE; // Rx line idle >= t3.5; wait for next frame
  }
  else if(modRcvCtrl.state == MOD_IDLE)
  { // Getting here means unexpected Rx line pause >= t1.5; try to sync
    CpuTimer1.PeriodInUSec = T1_3P5_TIME;
    CpuTimer1Regs.PRD.all = (long) CPU_FREQ_MHz * CpuTimer1.PeriodInUSec;
    CpuTimer1Regs.TCR.all = 0xC020; // Clear IF, enable int, load period, start
    modRcvCtrl.state = MOD_INIT; // Try to re-synchronize
  }
  else if(modRcvCtrl.state == MOD_RECEIVE)
  { // Getting here means possible expected end of frame, indicated by Rx line
    // pause >= t1.5. Check for frame error (CRC) and reset timer for
    // additional t2.0 for t3.5 total since start
    if(msgRcvA.msgLength < 8)
    {
      modRcvCtrl.CRC = 0;
      modRcvCtrl.frameErrorFlag = TRUE;
      modRcvCtrl.exceptCode = MOD_FRAME_ERROR;
    }
    else
    {
      modRcvCtrl.CRC = ComputeCRC(&msgRcvA, msgRcvA.msgLength - 2);

      if(((modRcvCtrl.CRC & 0x00FF) != msgRcvA.buf[msgRcvA.msgLength - 2]) ||
         (((modRcvCtrl.CRC & 0xFF00) >> 8) != msgRcvA.buf[msgRcvA.msgLength - 1]))
      { // CRCs did not match, so set frame error flag
        modRcvCtrl.frameErrorFlag = TRUE;
        modRcvCtrl.exceptCode = MOD_CRC_ERROR;
      }
    }
    CpuTimer1.PeriodInUSec = T1_2P0_TIME;
    CpuTimer1Regs.PRD.all = (long) CPU_FREQ_MHz * CpuTimer1.PeriodInUSec;
    CpuTimer1Regs.TCR.all = 0xC020; // Clear IF, enable int, load period, start
    modRcvCtrl.state = MOD_CTRL_WAIT;
  }
  else if(modRcvCtrl.state == MOD_CTRL_WAIT)
  { // Must have been at least t3.5 pause, so consider message received
    CpuTimer1Regs.TCR.all = 0x8010; // Clear IF, disable interrupt, stop timer
    if(modRcvCtrl.frameErrorFlag == FALSE)
    {
      modRcvCtrl.msgReceivedFlag = TRUE;
      modRcvCtrl.state = MOD_IDLE; // if frame error, error handler resets state
      modRcvCtrl.modAddr = msgRcvA.buf[0];
      modRcvCtrl.funcCode = msgRcvA.buf[1];
      modRcvCtrl.exceptCode = MOD_NO_ERROR; // Should already = no error, but make sure
    }
  }
  // The CPU acknowledges the interrupt, but make sure flag is clear
  CpuTimer1Regs.TCR.bit.TIF = 1;
}
