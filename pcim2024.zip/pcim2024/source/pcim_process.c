#include <include/pcim.h>
#include <include/pcim_globals.h>
#include <math.h>

//  Process GUI commands and run through the top-level state machine
void ProcessModbusCommands(void)
{
  // Update input registers
  if(modInputReg[MOD_IR_FAULT_CODE])
    modInputReg[MOD_IR_TOP_STATE] = SM_FAULT;

  if(modHoldReg[MOD_HR_RESET] == TRUE)
  { // Got a user reset
//    BREAKER_OFF; // Turn breaker off

    // Update input registers
    modInputReg[MOD_IR_FAULT_CODE] = 0;
    modInputReg[MOD_IR_MINS_TESTED] = 0;
    cal.currentCalDue = TRUE;
    modInputReg[MOD_IR_TOP_STATE] = SM_INIT;

    // Update holding registers
    modHoldReg[MOD_HR_RESET] = FALSE; // Set reset flag to false
//    modHoldReg[MOD_HR_RUN_FLAG] = FALSE;
  }

  if((modInputReg[MOD_IR_MINS_TESTED] >= modHoldReg[MOD_HR_DUR]) &&
     (modHoldReg[MOD_HR_STAY_ON] == 0))
  { // Tested time reached duration time so shut down
    modHoldReg[MOD_HR_ON_FLAG] = FALSE;
    modInputReg[MOD_IR_TOP_STATE] = SM_TIMEOUT;
  }

  // Run through state machine
  if(modInputReg[MOD_IR_TOP_STATE] == SM_FAULT)
  {
    BREAKER_OFF; // Turn breaker off
  }
  else if(modInputReg[MOD_IR_TOP_STATE] == SM_TIMEOUT)
  {
    BREAKER_OFF; // Turn breaker off
  }
  else if(modInputReg[MOD_IR_TOP_STATE] == SM_INIT)
  {
    if(cal.currentCalDue)
    {
      cal.zeroCurrentAdcCnt = filter2[CURRENT_FLTR].y[2]; // Store clean value from filter
      cal.currentCalDue = FALSE;
    }
    modInputReg[MOD_IR_TOP_STATE] = SM_OFF;
  }
  else if(modInputReg[MOD_IR_TOP_STATE] == SM_OFF)
  {
    BREAKER_OFF; // Turn breaker off

    modInputReg[MOD_IR_TOP_STATE] = SM_IDLE;
  }
  else if(modInputReg[MOD_IR_TOP_STATE] == SM_IDLE)
  {
    // See if user has set the on flag
    if(modHoldReg[MOD_HR_GUI_FLAG] && modHoldReg[MOD_HR_ON_FLAG])
    {
      BREAKER_ON; // Turn breaker on

      // Reset heartbeat timers
      time.millisecond = 0;
      time.halfSecond = 0;
      modInputReg[MOD_IR_TOP_STATE] = SM_ON;
    }
  }
  else if(modInputReg[MOD_IR_TOP_STATE] == SM_ON)
  {
    if(modHoldReg[MOD_HR_CAL_T_DUE])
    {
      cal.TjMeas = filter2[TJ_FLTR].y[2];
      cal.TjEntered = modHoldReg[MOD_HR_CAL_T_VAL];
      modHoldReg[MOD_HR_CAL_T_DUE] = FALSE;
    }

    if(!modHoldReg[MOD_HR_ON_FLAG])
      modInputReg[MOD_IR_TOP_STATE] = SM_OFF;
  }

  if(modHoldReg[MOD_HR_GUI_FLAG])
      GUI_LED_ON;
  else
      GUI_LED_OFF;
}
